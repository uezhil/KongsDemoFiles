﻿namespace KongsThreadDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, Threads!");
            //1.Creation of Thread Obj directly
            Thread threadobj1 = new Thread(ThreadFunc);
            
            //2.Creation of THread using aTHreadstart delegate
            ThreadStart threadel = new ThreadStart(ThreadFunc2);
            Thread threadobj2 = new Thread(threadel);

            //3.Creation of THread using Parameterized thread start
            Thread threadobj3 = new Thread(new ParameterizedThreadStart(ThreadFunc3));

            threadobj1.Start();
            //threadobj2.Start();
            threadobj3.Start("THread 3 starting now..");
            //priority
            Console.WriteLine( threadobj3.Priority );
            threadobj3.Priority = ThreadPriority.AboveNormal;
            Console.WriteLine(threadobj3.Priority);

            Console.WriteLine( "Bg thread" );
            bool status = threadobj3.IsBackground;
            Console.WriteLine("Is Alive");
            Console.WriteLine(threadobj3.IsAlive);
            Console.WriteLine("Interupting..");
            threadobj1.Interrupt();
        }

        static void ThreadFunc()
        {
            Console.WriteLine("THread 1 starting..");
            for (int i = 0; i < 10; i++)
            {
                try
                {
                    Console.WriteLine($"THread func 1:{i}");
                Thread.Sleep(3000);
            }
                catch (ThreadInterruptedException ex)
                {
                Console.WriteLine("Interupted exception handled..");
            }
                catch(Exception ex)
                {
                Console.WriteLine("Exception " + ex);
            }

        }
        }

        static void ThreadFunc2()
        {
            Console.WriteLine("THread 2 starting now..");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"THread func2:{i}");
                //Thread.Sleep(3000);
            }


        }

        static void ThreadFunc3(Object obj)
        {
            Console.WriteLine("THread 3 func 3 "+ obj);
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"THread func 3:{i}");
                Thread.Sleep(1000);
            }

        }
    }
}